#include <GLEW/glew.h>
#include <GLFW/glfw3.h>

#include <iostream>
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif


// GLM Mathematics
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <SOIL2/SOIL2.h>

using namespace std;

int width, height;
const double PI = 3.14159;
const float toRadians = PI / 180.0f;

// Declare Input Callback Function prototypes
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void mouse_button_callback(GLFWwindow* window, int button, int action, int mode);

// Declare View Matrix
glm::mat4 viewMatrix;

// Camera Field of View
GLfloat fov = 45.0f;

void initiateCamera();

// Define Camera Attributes
glm::vec3 cameraPosition = glm::vec3(0.0f, 0.0f, 3.0f); // Move 3 units back in z towards screen
glm::vec3 target = glm::vec3(0.0f, 0.0f, 0.0f); // What the camera points to
glm::vec3 cameraDirection = glm::normalize(cameraPosition - target); // direction z
glm::vec3 worldUp = glm::vec3(0.0, 1.0f, 0.0f);
glm::vec3 cameraRight = glm::normalize(glm::cross(worldUp, cameraDirection));// right vector x
glm::vec3 cameraUp = glm::normalize(glm::cross(cameraDirection, cameraRight)); // up vector y
glm::vec3 CameraFront = glm::vec3(0.0f, 0.0f, -1.0f); // 1 unit away from lense



// Camera Transformation Prototype
void TransformCamera();

// Boolean array for keys and mouse buttons
bool keys[1024], mouseButtons[3];

// Input state booleans
bool isPanning = false, isOrbiting = false;

// Pitch and Yaw
GLfloat radius = 3.0f, rawYaw = 0.0f, rawPitch = 0.0f, degYaw, degPitch;

GLfloat deltaTime = 0.0f;
GLfloat lastFrame = 0.0f;
GLfloat lastX = 320, lastY = 240, xChange, yChange; // Center mouse cursor
bool firstMouseMove = true;

// light position
glm::vec3 lightPosition(0.0f, 0.75f, 1.5f);

glm::vec3 pyramid3Position(1.5f, 0.0f, 1.5f);
glm::vec3 pyramid5Position(1.5f, 0.0f, -1.5f);

glm::vec3 leg1Position(-1.2f, -0.28f, -1.2f);
glm::vec3 leg2Position(-1.9f, -0.28f, -1.9f);
glm::vec3 leg3Position(-1.9f, -0.28f, -1.2f);
glm::vec3 leg4Position(-1.2f, -0.28f, -1.9f);

glm::vec3 spherePosition(-1.0f, 1.0f, -1.0f);

// Draw Primitive(s)
void draw()
{
	GLenum mode = GL_TRIANGLES;
	GLsizei indices = 6;
	glDrawElements(mode, indices, GL_UNSIGNED_BYTE, nullptr);
}

// Draw Primitive(s)
void draw2()
{
	GLenum mode = GL_TRIANGLES;
	GLsizei indices = 3;
	glDrawElements(mode, indices, GL_UNSIGNED_BYTE, nullptr);
}

// Draw Primitive(s)
void sphereDraw()
{
	GLenum mode = GL_TRIANGLES;
	GLsizei indices = 60;
	glDrawElements(mode, indices, GL_UNSIGNED_BYTE, nullptr);
}

void drawSphere(float radius, int slices, int stacks) {
	// Iterate through stacks (latitude)
	for (int i = 0; i < stacks; ++i) {
		float phi1 = M_PI * (float)i / stacks;
		float phi2 = M_PI * (float)(i + 1) / stacks;

		// Iterate through slices (longitude)
		for (int j = 0; j < slices; ++j) {
			float theta1 = 2 * M_PI * (float)j / slices;
			float theta2 = 2 * M_PI * (float)(j + 1) / slices;

			// Vertices of the current quad
			float x1 = radius * sin(phi1) * cos(theta1);
			float y1 = radius * sin(phi1) * sin(theta1);
			float z1 = radius * cos(phi1);

			float x2 = radius * sin(phi1) * cos(theta2);
			float y2 = radius * sin(phi1) * sin(theta2);
			float z2 = radius * cos(phi1);

			float x3 = radius * sin(phi2) * cos(theta2);
			float y3 = radius * sin(phi2) * sin(theta2);
			float z3 = radius * cos(phi2);

			float x4 = radius * sin(phi2) * cos(theta1);
			float y4 = radius * sin(phi2) * sin(theta1);
			float z4 = radius * cos(phi2);

			// Draw the quad
			glBegin(GL_QUADS);
			glVertex3f(x1, y1, z1);
			glVertex3f(x2, y2, z2);
			glVertex3f(x3, y3, z3);
			glVertex3f(x4, y4, z4);
			glEnd();
		}
	}
}

void drawTorus(float majorRadius, float minorRadius, int numMajorSegments, int numMinorSegments) {
	for (int i = 0; i < numMajorSegments; ++i) {
		float theta1 = 2 * M_PI * (float)i / numMajorSegments;
		float theta2 = 2 * M_PI * (float)(i + 1) / numMajorSegments;

		glBegin(GL_QUAD_STRIP);
		for (int j = 0; j <= numMinorSegments; ++j) {
			float phi = 2 * M_PI * (float)j / numMinorSegments;
			float cosPhi = cos(phi);
			float sinPhi = sin(phi);
			float cosTheta1 = cos(theta1);
			float sinTheta1 = sin(theta1);
			float cosTheta2 = cos(theta2);
			float sinTheta2 = sin(theta2);

			float x1 = (majorRadius + minorRadius * cosPhi) * cosTheta1;
			float y1 = (majorRadius + minorRadius * cosPhi) * sinTheta1;
			float z1 = minorRadius * sinPhi;

			float x2 = (majorRadius + minorRadius * cosPhi) * cosTheta2;
			float y2 = (majorRadius + minorRadius * cosPhi) * sinTheta2;
			float z2 = minorRadius * sinPhi;

			glVertex3f(x1, y1, z1);
			glVertex3f(x2, y2, z2);
		}
		glEnd();
	}
}




// Create and Compile Shaders
static GLuint CompileShader(const string& source, GLuint shaderType)
{
	// Create Shader object
	GLuint shaderID = glCreateShader(shaderType);
	const char* src = source.c_str();

	// Attach source code to Shader object
	glShaderSource(shaderID, 1, &src, nullptr);

	// Compile Shader
	glCompileShader(shaderID);

	// Return ID of Compiled shader
	return shaderID;

}

// Create Program Object
static GLuint CreateShaderProgram(const string& vertexShader, const string& fragmentShader)
{
	// Compile vertex shader
	GLuint vertexShaderComp = CompileShader(vertexShader, GL_VERTEX_SHADER);

	// Compile fragment shader
	GLuint fragmentShaderComp = CompileShader(fragmentShader, GL_FRAGMENT_SHADER);

	// Create program object
	GLuint shaderProgram = glCreateProgram();

	// Attach vertex and fragment shaders to program object
	glAttachShader(shaderProgram, vertexShaderComp);
	glAttachShader(shaderProgram, fragmentShaderComp);

	// Link shaders to create executable
	glLinkProgram(shaderProgram);

	// Delete compiled vertex and fragment shaders
	glDeleteShader(vertexShaderComp);
	glDeleteShader(fragmentShaderComp);

	// Return Shader Program
	return shaderProgram;

}


int main(void)
{
	width = 640; height = 480;

	GLFWwindow* window;

	/* Initialize the library */
	if (!glfwInit())
		return -1;

	/* Create a windowed mode window and its OpenGL context */
	window = glfwCreateWindow(width, height, "Main Window", NULL, NULL);
	if (!window)
	{
		glfwTerminate();
		return -1;
	}

	// Set input callback functions
	glfwSetKeyCallback(window, key_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetMouseButtonCallback(window, mouse_button_callback);
	glfwSetScrollCallback(window, scroll_callback);

	/* Make the window's context current */
	glfwMakeContextCurrent(window);

	// Initialize GLEW
	if (glewInit() != GLEW_OK)
		cout << "Error!" << endl;

	GLfloat lampVertices[] = {
		-0.5, -0.5, 0.0, // index 0
		-0.5, 0.5, 0.0,  // index 1
		0.5, -0.5, 0.0,  // index 2
		0.5, 0.5, 0.0    // index 3	
	};


	GLfloat cubeVertices[] = {

		// Triangle 1
		-0.5, -0.5, 0.0, // index 0
		1.0, 0.0, 0.0, // red
		0.0, 0.0,      //UV (bl)
		0.0f, 0.0f, 1.0f, // normal positive z

		-0.5, 0.5, 0.0, // index 1
		0.0, 1.0, 0.0, // green
		0.0, 1.0,      // UV (tl)
		0.0f, 0.0f, 1.0f, // normal positive z

		0.5, -0.5, 0.0,  // index 2	
		0.0, 0.0, 1.0, // blue
		1.0, 0.0,      // UV (bottom left)
		0.0f, 0.0f, 1.0f, // normal positive z

		// Triangle 2	
		0.5, 0.5, 0.0,  // index 3	
		1.0, 0.0, 1.0, // purple
		1.0, 1.0,       // UV (top right)
		0.0f, 0.0f, 1.0f // normal positive z
	};

	GLfloat pyramidVertices[] = {

		// Triangle 1
		-0.5, -0.5, 0.0, // index 0
		1.0, 0.0, 0.0, // red
		0.0, 0.0,      //UV 
		0.0f, 0.0f, 1.0f, // normal positive z

		0.0, 0.5, -0.5, // index 1 (high y)
		0.0, 1.0, 0.0, // green
		0.0, 1.0,      //UV 
		0.0f, 0.0f, 1.0f, // normal positive z

		0.5, -0.5, 0.0,  // index 2	
		0.0, 0.0, 1.0, // blue
		1.0, 0.0,      //UV 
		0.0f, 0.0f, 1.0f // normal positive z
	};

	GLfloat pyramid3Vertices[] = {

		// Triangle 1
		-0.5, -0.5, 0.0, // index 0
		1.0, 0.0, 0.0, // red
		0.0, 0.0,      //UV 
		0.0f, 0.0f, 1.0f, // normal positive z

		0.0, 0.4, -0.29, // index 1 (high y)
		0.0, 1.0, 0.0, // green
		0.0, 1.0,      //UV 
		0.0f, 0.0f, 1.0f, // normal positive z

		0.5, -0.5, 0.0,  // index 2	
		0.0, 0.0, 1.0, // blue
		1.0, 0.0,      //UV 
		0.0f, 0.0f, 1.0f // normal positive z
	};

	GLfloat pyramid5Vertices[] = {

		// Triangle 1
		-0.5, -0.5, 0.0, // index 0
		1.0, 0.0, 0.0, // red
		0.0, 0.0,      //UV 
		0.0f, 0.0f, 1.0f, // normal positive z

		0.0, 0.9, -0.67, // index 1 (high y)
		0.0, 1.0, 0.0, // green
		0.0, 1.0,      //UV 
		0.0f, 0.0f, 1.0f, // normal positive z

		0.5, -0.5, 0.0,  // index 2	
		0.0, 0.0, 1.0, // blue
		1.0, 0.0,      //UV 
		0.0f, 0.0f, 1.0f // normal positive z
	};

	GLfloat sphereVertices[] = {

		-1, 1.618, 0, // index 0
		1.0, 0.0, 0.0, // red
		0.0, 0.0,      //UV 
		0.0f, 0.0f, 1.0f, // normal positive z

		1, 1.618, 0, // index 1
		0.0, 1.0, 0.0, // green
		0.0, 1.0,      //UV 
		0.0f, 0.0f, 1.0f, // normal positive z

		-1, -1.618, 0,  // index 2	
		0.0, 0.0, 1.0, // blue
		1.0, 0.0,      //UV 
		0.0f, 0.0f, 1.0f, // normal positive z

		1, -1.618, 0,  // index 3	
		0.0, 0.0, 1.0, // blue
		1.0, 0.0,      //UV 
		0.0f, 0.0f, 1.0f, // normal positive z

		0, -1, 1.618,  // index 4	
		0.0, 0.0, 1.0, // blue
		1.0, 0.0,      //UV 
		0.0f, 0.0f, 1.0f, // normal positive z

		0, 1, 1.618,  // index 5	
		0.0, 0.0, 1.0, // blue
		1.0, 0.0,      //UV 
		0.0f, 0.0f, 1.0f, // normal positive z

		0, -1, -1.618,  // index 6
		0.0, 0.0, 1.0, // blue
		1.0, 0.0,      //UV 
		0.0f, 0.0f, 1.0f, // normal positive z

		0, 1, -1.618,  // index 7
		0.0, 0.0, 1.0, // blue
		1.0, 0.0,      //UV 
		0.0f, 0.0f, 1.0f, // normal positive z

		1.618, 0, -1,  // index 8
		0.0, 0.0, 1.0, // blue
		1.0, 0.0,      //UV 
		0.0f, 0.0f, 1.0f, // normal positive z

		1.618, 0, 1,  // index 9
		0.0, 0.0, 1.0, // blue
		1.0, 0.0,      //UV 
		0.0f, 0.0f, 1.0f, // normal positive z

		-1.618, 0, -1,  // index 10
		0.0, 0.0, 1.0, // blue
		1.0, 0.0,      //UV 
		0.0f, 0.0f, 1.0f, // normal positive z

		-1.618, 0, 1,  // index 11
		0.0, 0.0, 1.0, // blue
		1.0, 0.0,      //UV 
		0.0f, 0.0f, 1.0f // normal positive z
	};

	// Define element indices
	GLubyte indices[] = {
		0, 1, 2,
		1, 2, 3,
	};

	// Define element indices
	GLubyte indices2[] = {
		0, 1, 2
	};

	GLubyte sphereIndices[] = {
		0, 1, 6,
		0, 7, 1,
		0, 6, 9,
		0, 9, 11,
		0, 11, 7,
		1, 10, 6,
		6, 4, 9,
		9, 5, 11,
		11, 3, 7,
		7, 8, 1,
		3, 5, 4,
		3, 10, 5,
		3, 4, 10,
		2, 5, 9,
		2, 4, 5,
		2, 10, 4,
		2, 9, 11,
		2, 11, 3,
		2, 3, 10,
		8, 6, 1
	};

	// Plane Transforms
	glm::vec3 planePositions[] = {
		glm::vec3(0.0f,  0.0f,  0.5f),
		glm::vec3(0.5f,  0.0f,  0.0f),
		glm::vec3(0.0f,  0.0f,  -0.5f),
		glm::vec3(-0.5f, 0.0f,  0.0f),
		glm::vec3(0.0f, 0.5f,  0.0f),
		glm::vec3(0.0f, -0.5f,  0.0f)
	};

	glm::float32 planeRotations[] = {
		0.0f, 90.0f, 180.0f, -90.0f, -90.f, 90.f
	};

	// Plane Transforms
	glm::vec3 pyramidPlanePositions[] = {
		glm::vec3(1.5f,  0.0f,  0.5f),
		glm::vec3(2.0f,  0.0f,  0.0f),
		glm::vec3(1.5f,  0.0f,  -0.5f),
		glm::vec3(1.0f, 0.0f,  0.0f),
	};

	glm::float32 pyramidPlaneRotations[] = {
		0.0f, 90.0f, 180.0f, 270.0f
	};

	// Plane Transforms
	glm::vec3 pyramid3PlanePositions[] = {
		glm::vec3(-1.0f,  0.0f,  -0.57735f), // 1
		glm::vec3(0.0f,  0.0f,  1.155f),     // 3
		glm::vec3(1.0f,  0.0f,  -0.57735f),  // 2
	};

	glm::float32 pyramid3PlaneRotations[] = {
		240.0f, 0.0f, 120.0f
	};

	// Plane Transforms
	glm::vec3 pyramid5PlanePositions[] = {
		glm::vec3(0.0f,  0.0f,  1.0f),
		glm::vec3(0.951f,  0.0f,  0.309f),
		glm::vec3(0.588f,  0.0f,  -0.809f),
		glm::vec3(-0.588f,  0.0f,  -0.809f),
		glm::vec3(-0.951f,  0.0f,  0.309f)
	};

	glm::float32 pyramid5PlaneRotations[] = {
		0.0f, 72.0f, 144.0f, 216.0f, 288.0f
	};

	// Plane Transforms
	glm::vec3 cylinderPlanePositions[] = {
		glm::vec3(0.5f,  -0.25f,  1.5f),        // pos 3
		glm::vec3(0.3535f,  -0.25f,  1.8535f),  // pos 2
		glm::vec3(0.0f,  -0.25f,  2.0f),        // pos 1
		glm::vec3(-0.3535f,  -0.25f,  1.8535f),  // pos 8
		glm::vec3(-0.5f,  -0.25f,  1.5f),        // pos 7
		glm::vec3(-0.3535f,  -0.25f, 1.1465f), // pos 6
		glm::vec3(0.0f, -0.25f,  1.0f),        // pos 5
		glm::vec3(0.3535f, -0.25f,  1.1465f)   // pos 4
	};


	glm::float32 cylinderPlaneRotations[] = {
		90.0f, 45.0f, 0.0f, 315.0f, 270.0f, 225.0f, 180.0f, 135.0f
	};

	// Setup some OpenGL options
	glEnable(GL_DEPTH_TEST);

	// Wireframe mode
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	GLuint cubeVBO, cubeEBO, cubeVAO,
		   floorVBO, floorEBO, floorVAO,
		   pyramidVBO, pyramidEBO, pyramidVAO,
		   pyramid3VBO, pyramid3EBO, pyramid3VAO,
		   pyramid5VBO, pyramid5EBO, pyramid5VAO,
		   cylinderVBO, cylinderEBO, cylinderVAO,
		   lampVBO, lampEBO, lampVAO,
		   sphereVBO, sphereEBO, sphereVAO,
		   leg1VBO, leg1EBO, leg1VAO,
	       leg2VBO, leg2EBO, leg2VAO,
	       leg3VBO, leg3EBO, leg3VAO,
	       leg4VBO, leg4EBO, leg4VAO;

	glGenBuffers(1, &cubeVBO); // Create VBO
	glGenBuffers(1, &cubeEBO); // Create EBO

	glGenBuffers(1, &floorVBO); // Create VBO
	glGenBuffers(1, &floorEBO); // Create EBO

	glGenBuffers(1, &pyramidVBO); // Create VBO
	glGenBuffers(1, &pyramidEBO); // Create EBO

	glGenBuffers(1, &pyramid3VBO); // Create VBO
	glGenBuffers(1, &pyramid3EBO); // Create EBO

	glGenBuffers(1, &pyramid5VBO); // Create VBO
	glGenBuffers(1, &pyramid5EBO); // Create EBO

	glGenBuffers(1, &cylinderVBO); // Create VBO
	glGenBuffers(1, &cylinderEBO); // Create EBO

	glGenBuffers(1, &lampVBO); // Create VBO
	glGenBuffers(1, &lampEBO); // Create EBO

	glGenBuffers(1, &sphereVBO); // Create VBO
	glGenBuffers(1, &sphereEBO); // Create EBO

	glGenBuffers(1, &leg1VBO); // Create VBO
	glGenBuffers(1, &leg1EBO); // Create EBO

	glGenBuffers(1, &leg2VBO); // Create VBO
	glGenBuffers(1, &leg2EBO); // Create EBO

	glGenBuffers(1, &leg3VBO); // Create VBO
	glGenBuffers(1, &leg3EBO); // Create EBO

	glGenBuffers(1, &leg4VBO); // Create VBO
	glGenBuffers(1, &leg4EBO); // Create EBO

	glGenVertexArrays(1, &cubeVAO); // Create VOA
	glGenVertexArrays(1, &floorVAO); // Create VOA
	glGenVertexArrays(1, &pyramidVAO); // Create VOA
	glGenVertexArrays(1, &pyramid3VAO); // Create VOA
	glGenVertexArrays(1, &pyramid5VAO); // Create VOA
	glGenVertexArrays(1, &cylinderVAO); // Create VOA
	glGenVertexArrays(1, &lampVAO); // Create VOA
	glGenVertexArrays(1, &sphereVAO); // Create VOA
	glGenVertexArrays(1, &leg1VAO); // Create VOA
	glGenVertexArrays(1, &leg2VAO); // Create VOA
	glGenVertexArrays(1, &leg3VAO); // Create VOA
	glGenVertexArrays(1, &leg4VAO); // Create VOA

	glBindVertexArray(cubeVAO);

	// VBO and EBO Placed in User-Defined VAO
	glBindBuffer(GL_ARRAY_BUFFER, cubeVBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, cubeEBO); // Select EBO


	glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVertices), cubeVertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

	// Specify attribute location and layout to GPU
	// position stride
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);

	// color stride
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	// texture stride
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	// normal stride
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);

	glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

	glBindVertexArray(leg1VAO);

	// VBO and EBO Placed in User-Defined VAO
	glBindBuffer(GL_ARRAY_BUFFER, leg1VBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, leg1EBO); // Select EBO


	glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVertices), cubeVertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

	// Specify attribute location and layout to GPU
	// position stride
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);

	// color stride
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	// texture stride
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	// normal stride
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);

	glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

	glBindVertexArray(leg2VAO);

	// VBO and EBO Placed in User-Defined VAO
	glBindBuffer(GL_ARRAY_BUFFER, leg2VBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, leg2EBO); // Select EBO


	glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVertices), cubeVertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

	// Specify attribute location and layout to GPU
	// position stride
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);

	// color stride
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	// texture stride
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	// normal stride
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);

	glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

	glBindVertexArray(leg3VAO);

	// VBO and EBO Placed in User-Defined VAO
	glBindBuffer(GL_ARRAY_BUFFER, leg3VBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, leg3EBO); // Select EBO


	glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVertices), cubeVertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

	// Specify attribute location and layout to GPU
	// position stride
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);

	// color stride
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	// texture stride
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	// normal stride
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);

	glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

	glBindVertexArray(leg4VAO);

	// VBO and EBO Placed in User-Defined VAO
	glBindBuffer(GL_ARRAY_BUFFER, leg4VBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, leg4EBO); // Select EBO


	glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVertices), cubeVertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

	// Specify attribute location and layout to GPU
	// position stride
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);

	// color stride
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	// texture stride
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	// normal stride
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);

	glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

	glBindVertexArray(lampVAO);
		glBindBuffer(GL_ARRAY_BUFFER, lampVBO); // Select VBO
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, lampEBO); // Select EBO

		glBufferData(GL_ARRAY_BUFFER, sizeof(lampVertices), lampVertices, GL_STATIC_DRAW); // Load vertex attributes
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

		glBufferData(GL_ARRAY_BUFFER, sizeof(sphereVertices), sphereVertices, GL_STATIC_DRAW); // Load vertex attributes
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(sphereIndices), sphereIndices, GL_STATIC_DRAW); // Load indices 

		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0 * sizeof(GLfloat), (GLvoid*)0);
		glEnableVertexAttribArray(0);
	glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

	glBindVertexArray(pyramidVAO);

	// VBO and EBO Placed in User-Defined VAO
	glBindBuffer(GL_ARRAY_BUFFER, pyramidVBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, pyramidEBO); // Select EBO


	glBufferData(GL_ARRAY_BUFFER, sizeof(pyramidVertices), pyramidVertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices2), indices2, GL_STATIC_DRAW); // Load indices 

	// Specify attribute location and layout to GPU
	// position stride
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);

	// color stride
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	// texture stride
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	// normal/lighting stride
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);

	glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

	glBindVertexArray(pyramid3VAO);

	// VBO and EBO Placed in User-Defined VAO
	glBindBuffer(GL_ARRAY_BUFFER, pyramid3VBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, pyramid3EBO); // Select EBO


	glBufferData(GL_ARRAY_BUFFER, sizeof(pyramid3Vertices), pyramid3Vertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices2), indices2, GL_STATIC_DRAW); // Load indices 

	// Specify attribute location and layout to GPU
	// position stride
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);

	// color stride
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	// texture stride
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	// normal/lighting stride
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);

	glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

	glBindVertexArray(pyramid5VAO);

	// VBO and EBO Placed in User-Defined VAO
	glBindBuffer(GL_ARRAY_BUFFER, pyramid5VBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, pyramid5EBO); // Select EBO


	glBufferData(GL_ARRAY_BUFFER, sizeof(pyramid5Vertices), pyramid5Vertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices2), indices2, GL_STATIC_DRAW); // Load indices 

	// Specify attribute location and layout to GPU
	// position stride
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);

	// color stride
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	// texture stride
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	// normal/lighting stride
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);

	glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

	glBindVertexArray(cylinderVAO);

	// VBO and EBO Placed in User-Defined VAO
	glBindBuffer(GL_ARRAY_BUFFER, cubeVBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, cubeEBO); // Select EBO


	glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVertices), cubeVertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

	// Specify attribute location and layout to GPU
	// position stride
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);

	// color stride
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	// texture stride
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	// normal stride
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);

	glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)


	glBindVertexArray(floorVAO);

	glBindBuffer(GL_ARRAY_BUFFER, floorVBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, floorEBO); // Select EBO

	glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVertices), cubeVertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);

	glBindVertexArray(0);

	glBindVertexArray(sphereVAO);

	// VBO and EBO Placed in User-Defined VAO
	glBindBuffer(GL_ARRAY_BUFFER, sphereVBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, sphereEBO); // Select EBO


	glBufferData(GL_ARRAY_BUFFER, sizeof(sphereVertices), sphereVertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(sphereIndices), sphereIndices, GL_STATIC_DRAW); // Load indices 

	// Specify attribute location and layout to GPU
	// position stride
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);

	// color stride
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	// texture stride
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	// normal stride
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);

	glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

	// load textures
	int crateTexWidth, crateTexHeight, gridTexWidth, gridTexHeight, snhuTexWidth, snhuTexHeight, floorTexWidth, floorTexHeight, tileTexWidth, tileTexHeight;
	unsigned char* crateImage = SOIL_load_image("crate.png", &crateTexWidth, &crateTexHeight, 0, SOIL_LOAD_RGB);
	unsigned char* gridImage = SOIL_load_image("grid.png", &gridTexWidth, &gridTexHeight, 0, SOIL_LOAD_RGB);
	unsigned char* snhuImage = SOIL_load_image("snhu.jpg", &snhuTexWidth, &snhuTexHeight, 0, SOIL_LOAD_RGB);
	unsigned char* floorImage = SOIL_load_image("floor.jpg", &floorTexWidth, &floorTexHeight, 0, SOIL_LOAD_RGB);
	unsigned char* tileImage = SOIL_load_image("tile.png", &tileTexWidth, &tileTexHeight, 0, SOIL_LOAD_RGB);

	// generate textures
	GLuint crateTexture;
	glGenTextures(1, &crateTexture);
	glBindTexture(GL_TEXTURE_2D, crateTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, crateTexWidth, crateTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, crateImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(crateImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	GLuint gridTexture;
	glGenTextures(1, &gridTexture);
	glBindTexture(GL_TEXTURE_2D, gridTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, gridTexWidth, gridTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, gridImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(gridImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	GLuint snhuTexture;
	glGenTextures(1, &snhuTexture);
	glBindTexture(GL_TEXTURE_2D, snhuTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, snhuTexWidth, snhuTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, snhuImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(snhuImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	GLuint floorTexture;
	glGenTextures(1, &floorTexture);
	glBindTexture(GL_TEXTURE_2D, floorTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, floorTexWidth, floorTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, floorImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(floorImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	GLuint tileTexture;
	glGenTextures(1, &tileTexture);
	glBindTexture(GL_TEXTURE_2D, tileTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, tileTexWidth, tileTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, tileImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(tileImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	// Vertex shader source code
	string vertexShaderSource =
		"#version 330 core\n"

		"layout(location = 0) in vec3 vPosition;"
		"layout(location = 1) in vec3 aColor;"
		"layout(location = 2) in vec2 texCoord;"
		"layout(location = 3) in vec3 normal;"

		"out vec3 oColor;"
		"out vec2 oTexCoord;"
		"out vec3 oNormal;"
		"out vec3 FragPos;"

		"uniform mat4 model;"
		"uniform mat4 view;"
		"uniform mat4 projection;"

		"void main()\n"
		"{\n"
		"gl_Position = projection * view * model * vec4(vPosition.x, vPosition.y, vPosition.z, 1.0);"
		"oColor = aColor;"
		"oTexCoord = texCoord;"
		"oNormal = mat3(transpose(inverse(model))) * normal;"
		"FragPos = vec3(model * vec4(vPosition, 1.0f));"
		"}\n";

	// Fragment shader source code
	string fragmentShaderSource =
		"#version 330 core\n"

		"in vec3 oColor;"
		"in vec2 oTexCoord;"
		"in vec3 oNormal;"
		"in vec3 FragPos;"

		"out vec4 fragColor;"

		"uniform sampler2D myTexture;"
		"uniform vec3 objectColor;"
		"uniform vec3 lightColor;"
		"uniform vec3 lightPos;"
		"uniform vec3 viewPos;"

		"void main()\n"  
		"{\n"  

		"float ambientStrength = 0.3f;"    // ambient
		"vec3 ambient = ambientStrength * lightColor;"

		"vec3 norm = normalize(oNormal);" // diffuse
		"vec3 lightDir = normalize(lightPos - FragPos);"
		"float diff = max(dot(norm, lightDir), 0.0);"
		"vec3 diffuse = diff * lightColor;"

		"float specularStrength = 1.5f;" // specular
		"vec3 viewDir = normalize(viewPos - FragPos);"
		"vec3 reflectDir = reflect(-lightDir, norm);"
		"float spec = pow(max(dot(viewDir, reflectDir), 0.0), 128);"
		"vec3 specular = specularStrength * spec * lightColor;"

		"vec3 result = (ambient + diffuse + specular) * objectColor;"
		"fragColor = texture(myTexture, oTexCoord) * vec4(result, 1.0f);"
		"}\n";

	// Vertex shader source code
	string lampVertexShaderSource =
		"#version 330 core\n"

		"layout(location = 0) in vec3 vPosition;"

		"uniform mat4 model;"
		"uniform mat4 view;"
		"uniform mat4 projection;"

		"void main()\n"
		"{\n"
		"gl_Position = projection * view * model * vec4(vPosition.x, vPosition.y, vPosition.z, 1.0);"
		"}\n";

	// Fragment shader source code
	string lampFragmentShaderSource =
		"#version 330 core\n"

		"out vec4 fragColor;"

		"void main()\n"
		"{\n"
		"fragColor = vec4(1.0f);"
		"}\n";

	// Creating Shader Program
	GLuint shaderProgram = CreateShaderProgram(vertexShaderSource, fragmentShaderSource);
	GLuint lampShaderProgram = CreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource);


	/* Loop until the user closes the window */
	while (!glfwWindowShouldClose(window))
	{
		// Set frame time
		GLfloat currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		// Resize window and graphics simultaneously
		glfwGetFramebufferSize(window, &width, &height);
		glViewport(0, 0, width, height);

		/* Render here */
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Use Shader Program exe and select VAO before drawing 
		glUseProgram(shaderProgram); // Call Shader per-frame when updating attributes


		// Declare transformations (can be initialized outside loop)		
		glm::mat4 projectionMatrix;

		// Define LookAt Matrix
		viewMatrix = glm::lookAt(cameraPosition, target, worldUp);

		// Define projection matrix
		projectionMatrix = glm::perspective(fov, (GLfloat)width / (GLfloat)height, 0.1f, 100.0f);

		// Get matrix's uniform location and set matrix
		GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
		GLint viewLoc = glGetUniformLocation(shaderProgram, "view");
		GLint projLoc = glGetUniformLocation(shaderProgram, "projection");

		// get light and object location
		GLint objectColorLoc = glGetUniformLocation(shaderProgram, "objectColor");
		GLint lightColorLoc = glGetUniformLocation(shaderProgram, "lightColor");
		GLint lgihtPosLoc = glGetUniformLocation(shaderProgram, "lightPos");
		GLint viewPosLoc = glGetUniformLocation(shaderProgram, "viewPos");

		// assign colors
		// crate color (x/255) = value
		glUniform3f(objectColorLoc, 0.46f, 0.36f, 0.25f);
		// snhu color (x/255) = value
		//glUniform3f(objectColorLoc, 0.38f, 0.17f, 0.08f);
		// grid color (x/255) = value
		// glUniform3f(objectColorLoc, 1.0f, 0.0f, 1.0f);

		glUniform3f(lightColorLoc, 1.0f, 1.0f, 1.0f);

		// set light position
		glUniform3f(lgihtPosLoc, lightPosition.x, lightPosition.y, lightPosition.z);

		// specify view position
		glUniform3f(viewPosLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

		glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(viewMatrix));
		glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

		glBindTexture(GL_TEXTURE_2D, snhuTexture);
		glBindVertexArray(cubeVAO); // User-defined VAO must be called before draw. 

		// Transform planes to form cube
		for (GLuint i = 0; i < 6; i++)
		{
			glm::mat4 modelMatrix;
			modelMatrix = glm::translate(modelMatrix, planePositions[i]);
			modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			if (i >= 4)
				modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			// Draw primitive(s)
			draw();
		}

		// Unbind Shader exe and VOA after drawing per frame
		glBindVertexArray(0); //Incase different VAO wii be used after

		glBindTexture(GL_TEXTURE_2D, crateTexture);
		glBindVertexArray(leg1VAO); // User-defined VAO must be called before draw. 

		// Transform planes to form cube
		for (GLuint i = 0; i < 6; i++)
		{
			glm::mat4 modelMatrix;
			modelMatrix = glm::translate(modelMatrix, planePositions[i] / glm::vec3(5., 5., 5.) + leg1Position);
			modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			modelMatrix = glm::scale(modelMatrix, glm::vec3(0.2f, 0.45f, 0.2f));
			if (i >= 4)
				modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			// Draw primitive(s)
			draw();
		}

		// Unbind Shader exe and VOA after drawing per frame
		glBindVertexArray(0); //Incase different VAO wii be used after

		glBindTexture(GL_TEXTURE_2D, crateTexture);
		glBindVertexArray(leg2VAO); // User-defined VAO must be called before draw. 

		// Transform planes to form cube
		for (GLuint i = 0; i < 6; i++)
		{
			glm::mat4 modelMatrix;
			modelMatrix = glm::translate(modelMatrix, planePositions[i] / glm::vec3(5., 5., 5.) + leg2Position);
			modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			modelMatrix = glm::scale(modelMatrix, glm::vec3(0.2f, 0.45f, 0.2f));
			if (i >= 4)
				modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			// Draw primitive(s)
			draw();
		}

		// Unbind Shader exe and VOA after drawing per frame
		glBindVertexArray(0); //Incase different VAO wii be used after

		glBindTexture(GL_TEXTURE_2D, crateTexture);
		glBindVertexArray(leg3VAO); // User-defined VAO must be called before draw. 

		// Transform planes to form cube
		for (GLuint i = 0; i < 6; i++)
		{
			glm::mat4 modelMatrix;
			modelMatrix = glm::translate(modelMatrix, planePositions[i] / glm::vec3(5., 5., 5.) + leg3Position);
			modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			modelMatrix = glm::scale(modelMatrix, glm::vec3(0.2f, 0.45f, 0.2f));
			if (i >= 4)
				modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			// Draw primitive(s)
			draw();
		}

		// Unbind Shader exe and VOA after drawing per frame
		glBindVertexArray(0); //Incase different VAO wii be used after

		glBindTexture(GL_TEXTURE_2D, crateTexture);
		glBindVertexArray(leg4VAO); // User-defined VAO must be called before draw. 

		// Transform planes to form cube
		for (GLuint i = 0; i < 6; i++)
		{
			glm::mat4 modelMatrix;
			modelMatrix = glm::translate(modelMatrix, planePositions[i] / glm::vec3(5., 5., 5.) + leg4Position);
			modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			modelMatrix = glm::scale(modelMatrix, glm::vec3(0.2f, 0.45f, 0.2f));
			if (i >= 4)
				modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			// Draw primitive(s)
			draw();
		}

		// Unbind Shader exe and VOA after drawing per frame
		glBindVertexArray(0); //Incase different VAO wii be used after

		glBindTexture(GL_TEXTURE_2D, floorTexture);
		glBindVertexArray(pyramidVAO); // User-defined VAO must be called before draw. 

		// Transform planes to form cube
		for (GLuint i = 0; i < 4; i++)
		{
			glm::mat4 modelMatrix;
			modelMatrix = glm::translate(modelMatrix, pyramidPlanePositions[i]);
			modelMatrix = glm::rotate(modelMatrix, pyramidPlaneRotations[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			// modelMatrix = glm::scale(modelMatrix, glm::vec3(3.f, 3.f, 3.f));
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			// Draw primitive(s)
			draw2();
		}

		// Unbind Shader exe and VOA after drawing per frame
		glBindVertexArray(0); //Incase different VAO wii be used after

		glBindTexture(GL_TEXTURE_2D, floorTexture);
		glBindVertexArray(pyramid3VAO); // User-defined VAO must be called before draw. 

		// Transform planes to form cube
		for (GLuint i = 0; i < 3; i++)
		{
			glm::mat4 modelMatrix;
			modelMatrix = glm::translate(modelMatrix, pyramid3PlanePositions[i] / glm::vec3(4.0, 4.0, 4.0) + pyramid3Position); // / glm::vec3(2.0, 2.0, 2.0)
			modelMatrix = glm::rotate(modelMatrix, pyramid3PlaneRotations[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			// modelMatrix = glm::scale(modelMatrix, glm::vec3(3.f, 3.f, 3.f));
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			// Draw primitive(s)
			draw2();
		}

		// Unbind Shader exe and VOA after drawing per frame
		glBindVertexArray(0); //Incase different VAO wii be used after

		glBindTexture(GL_TEXTURE_2D, floorTexture);
		glBindVertexArray(pyramid5VAO); // User-defined VAO must be called before draw. 

		// Transform planes to form cube
		for (GLuint i = 0; i < 5; i++)
		{
			glm::mat4 modelMatrix;
			modelMatrix = glm::translate(modelMatrix, pyramid5PlanePositions[i] / glm::vec3(1.5, 1.5, 1.5) + pyramid5Position); /// glm::vec3(2.27, 2.27, 2.27)
			modelMatrix = glm::rotate(modelMatrix, pyramid5PlaneRotations[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			// modelMatrix = glm::scale(modelMatrix, glm::vec3(3.f, 3.f, 3.f));
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			// Draw primitive(s)
			draw2();
		}

		// Unbind Shader exe and VOA after drawing per frame
		glBindVertexArray(0); //Incase different VAO wii be used after

		glBindTexture(GL_TEXTURE_2D, crateTexture);
		glBindVertexArray(cylinderVAO); // User-defined VAO must be called before draw. 

		// Transform planes to form cube
		for (GLuint i = 0; i < 8; i++)
		{
			glm::mat4 modelMatrix;
			modelMatrix = glm::translate(modelMatrix, cylinderPlanePositions[i]);
			modelMatrix = glm::rotate(modelMatrix, cylinderPlaneRotations[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			modelMatrix = glm::scale(modelMatrix, glm::vec3(0.415f, 0.5f, 1.0f));
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			// Draw primitive(s)
			draw();
		}

		// Unbind Shader exe and VOA after drawing per frame
		glBindVertexArray(0); //Incase different VAO wii be used after




		glBindTexture(GL_TEXTURE_2D, gridTexture);
		// Select and transform floor
		glBindVertexArray(floorVAO);
		glm::mat4 modelMatrix;
		modelMatrix = glm::translate(modelMatrix, glm::vec3(0.f, -.5f, 0.f));
		modelMatrix = glm::rotate(modelMatrix, 90.f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(5.f, 5.f, 5.f));
		glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
		draw();
		glBindVertexArray(0); //Incase different VAO will be used after


		glBindTexture(GL_TEXTURE_2D, floorTexture);
		glBindVertexArray(sphereVAO); // User-defined VAO must be called before draw. 
		// glm::mat4 modelMatrix;
		modelMatrix = glm::translate(modelMatrix, glm::vec3(-0.3f, -0.3f, -0.13f)); // (x, z, y)
		// //modelMatrix = glm::rotate(modelMatrix, 90.f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
		// modelMatrix = glm::scale(modelMatrix, glm::vec3(0.05f, 0.05f, 0.05f));
		glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
		// sphereDraw();
		drawTorus(0.1, 0.05, 30, 20); // Major radius, minor radius, num major segments, num minor segments

		// Unbind Shader exe and VOA after drawing per frame
		glBindVertexArray(0); //Incase different VAO wii be used after

		glUseProgram(0); // Incase different shader will be used after

		glUseProgram(lampShaderProgram);

			// Get matrix's uniform location and set matrix
			GLint lampModelLoc = glGetUniformLocation(lampShaderProgram, "model");
			GLint lampViewLoc = glGetUniformLocation(lampShaderProgram, "view");
			GLint lampProjLoc = glGetUniformLocation(lampShaderProgram, "projection");
			glUniformMatrix4fv(lampViewLoc, 1, GL_FALSE, glm::value_ptr(viewMatrix));
			glUniformMatrix4fv(lampProjLoc, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

			glBindVertexArray(lampVAO); // User-defined VAO must be called before draw. 

			// Transform planes to form cube
			  for (GLuint i = 0; i < 6; i++)
			  {
			 	glm::mat4 modelMatrix;
			  	modelMatrix = glm::translate(modelMatrix, planePositions[i] + lightPosition); // / glm::vec3(8.,8.,8.)
			  	modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			 	modelMatrix = glm::scale(modelMatrix, glm::vec3(1.0f, 1.0f, 1.0f));  // .125
			 	if (i >= 4)
			  		modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			  	glUniformMatrix4fv(lampModelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			  //	Draw primitive(s)
                 //draw();
			  }
			drawSphere(0.6, 12, 12); // Radius, slices, stacks

			// Unbind Shader exe and VOA after drawing per frame
			glBindVertexArray(0); //Incase different VAO wii be used after

		glUseProgram(0);

		/* Swap front and back buffers */
		glfwSwapBuffers(window);

		/* Poll for and process events */
		glfwPollEvents();

		// Poll Camera Transformations
		TransformCamera();

	}

	//Clear GPU resources
	glDeleteVertexArrays(1, &cubeVAO);
	glDeleteBuffers(1, &cubeVBO);
	glDeleteBuffers(1, &cubeEBO);

	glDeleteVertexArrays(1, &floorVAO);
	glDeleteBuffers(1, &floorVBO);
	glDeleteBuffers(1, &floorEBO);

	glDeleteVertexArrays(1, &cylinderVAO);
	glDeleteBuffers(1, &cylinderVBO);
	glDeleteBuffers(1, &cylinderEBO);

	glDeleteVertexArrays(1, &lampVAO);
	glDeleteBuffers(1, &lampVBO);
	glDeleteBuffers(1, &lampEBO);

	glDeleteVertexArrays(1, &pyramidVAO);
	glDeleteBuffers(1, &pyramidVBO);
	glDeleteBuffers(1, &pyramidEBO);

	glDeleteVertexArrays(1, &sphereVAO);
	glDeleteBuffers(1, &sphereVBO);
	glDeleteBuffers(1, &sphereEBO);

	glfwTerminate();
	return 0;
}

// Define input functions
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode)
{
	// Display ASCII Key code
	//std::cout <<"ASCII: "<< key << std::endl;	

	// Close window
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, GL_TRUE);

	// Assign true to Element ASCII if key pressed
	if (action == GLFW_PRESS)
		keys[key] = true;
	else if (action == GLFW_RELEASE) // Assign false to Element ASCII if key released
		keys[key] = false;

}
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{

	// Clamp FOV
	if (fov >= 1.0f && fov <= 55.0f)
		fov -= yoffset * 0.01;

	// Default FOV
	if (fov < 1.0f)
		fov = 1.0f;
	if (fov > 55.0f)
		fov = 55.0f;

}
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{

	if (firstMouseMove)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouseMove = false;
	}
	// Calculate mouse offset (Easing effect)
	xChange = xpos - lastX;
	yChange = lastY - ypos; // Inverted cam

	// Get current mouse (always starts at 0)
	lastX = xpos;
	lastY = ypos;


	if (isOrbiting)
	{
		// Update raw yaw and pitch with mouse movement
		rawYaw += xChange;
		rawPitch += yChange;

		// Conver yaw and pitch to degrees, and clamp pitch
		degYaw = glm::radians(rawYaw);
		degPitch = glm::clamp(glm::radians(rawPitch), -glm::pi<float>() / 2.f + .1f, glm::pi<float>() / 2.f - .1f);

		// Azimuth Altitude formula
		cameraPosition.x = target.x + radius * cosf(degPitch) * sinf(degYaw);
		cameraPosition.y = target.y + radius * sinf(degPitch);
		cameraPosition.z = target.z + radius * cosf(degPitch) * cosf(degYaw);
	}
}
void mouse_button_callback(GLFWwindow* window, int button, int action, int mode)
{
	// Assign boolean state to element Button code
	if (action == GLFW_PRESS)
		mouseButtons[button] = true;
	else if (action == GLFW_RELEASE)
		mouseButtons[button] = false;
}



// Define TransformCamera function
void TransformCamera()
{

	// Orbit camera
	if (keys[GLFW_KEY_LEFT_ALT] && mouseButtons[GLFW_MOUSE_BUTTON_LEFT])
		isOrbiting = true;
	else
		isOrbiting = false;

	// Focus camera
	if (keys[GLFW_KEY_F])
		initiateCamera();
}

// Define 
void initiateCamera()
{	// Define Camera Attributes
	cameraPosition = glm::vec3(0.0f, 0.0f, 3.0f); // Move 3 units back in z towards screen
	target = glm::vec3(0.0f, 0.0f, 0.0f); // What the camera points to
	cameraDirection = glm::normalize(cameraPosition - cameraDirection); // direction z
	worldUp = glm::vec3(0.0, 1.0f, 0.0f);
	cameraRight = glm::normalize(glm::cross(worldUp, cameraDirection));// right vector x
	cameraUp = glm::normalize(glm::cross(cameraDirection, cameraRight)); // up vector y
	CameraFront = glm::vec3(0.0f, 0.0f, -1.0f); // 1 unit away from lense
}
